<?php
$xml=simplexml_load_file("mapdata.xml");
print ($xml);
?>